const api = typeof browser !== 'undefined' ? browser : chrome;

function showBadge(tabId) {
  api.action.setBadgeBackgroundColor({ tabId, color: '#dc2743' });
  api.action.setBadgeText({ tabId, text: '!' });
  setTimeout(() => api.action.setBadgeText({ tabId, text: '' }), 3000);
}

api.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;

  const isInstagram = tab.url && /^https:\/\/([^/]+\.)?instagram\.com\//.test(tab.url);

  if (!isInstagram) {
    // Show a message on normal web pages; fall back to a badge on browser-internal pages.
    try {
      await api.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'MAIN',
        func: () => alert('Please open instagram.com first')
      });
    } catch (e) {
      showBadge(tab.id);
    }
    return;
  }

  try {
    await api.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      files: ['inject.js']
    });
  } catch (e) {
    console.warn('Injection failed:', e);
  }
});
